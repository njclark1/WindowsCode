/*reveal hidden message*/
function revealMessage() {
    document.getElementById("site").style.display = 'block';
}