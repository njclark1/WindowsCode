package dev.nclark.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomemanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomemanagerApplication.class, args);
	}

}
